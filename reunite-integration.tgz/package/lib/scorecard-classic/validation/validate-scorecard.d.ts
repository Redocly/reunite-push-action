import type { ScorecardConfig } from '@redocly/config';
import { type Document, type Plugin, type BaseResolver } from '@redocly/openapi-core';
import type { ScorecardProblem } from '../types.js';
export type ScorecardValidationResult = {
    problems: ScorecardProblem[];
    achievedLevel: string;
    targetLevelAchieved: boolean;
};
export type ValidateScorecardParams = {
    apiPath: string;
    document: Document;
    externalRefResolver: BaseResolver;
    scorecardConfig: ScorecardConfig;
    configPath?: string;
    plugins?: Plugin[];
    targetLevel?: string;
    metadata?: Record<string, unknown>;
    onDebug?: (message: string) => void;
};
export declare function validateScorecard({ apiPath, document, externalRefResolver, scorecardConfig, configPath, plugins, targetLevel, metadata, onDebug, }: ValidateScorecardParams): Promise<ScorecardValidationResult>;
//# sourceMappingURL=validate-scorecard.d.ts.map
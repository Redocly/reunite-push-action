export declare function isAllowedScorecardProjectUrl(urlString: string): boolean;
//# sourceMappingURL=project-url.d.ts.map
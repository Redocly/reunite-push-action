import { type Plugin } from '@redocly/openapi-core';
export declare function evaluatePluginsFromCode(pluginsCode?: string, basePath?: string): Promise<Plugin[]>;
//# sourceMappingURL=plugin-evaluator.d.ts.map
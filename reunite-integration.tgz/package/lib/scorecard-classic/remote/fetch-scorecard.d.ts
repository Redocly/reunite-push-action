import type { RemoteScorecardAndPlugins } from '../types.js';
export type FetchRemoteScorecardAndPluginsParams = {
    projectUrl: string;
    auth: string;
    isApiKey?: boolean;
    onDebug?: (message: string) => void;
};
export declare function fetchRemoteScorecardAndPlugins({ projectUrl, auth, isApiKey, onDebug, }: FetchRemoteScorecardAndPluginsParams): Promise<RemoteScorecardAndPlugins>;
//# sourceMappingURL=fetch-scorecard.d.ts.map
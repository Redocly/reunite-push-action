import { type ScorecardConfig } from '@redocly/config';
import { type Config, type Plugin } from '@redocly/openapi-core';
export declare function resolveConfigForTarget(apiPath: string, targetRules: Record<string, unknown> | undefined, scorecardLevels: ScorecardConfig['levels'], plugins: Array<string | Plugin> | undefined, configPath: string): Promise<Record<string, Config>>;
export declare function getTarget<T extends object>(targets: Array<{
    where: {
        metadata: Record<string, string>;
    };
} & T> | undefined, metadata: Record<string, unknown>): ({
    where: {
        metadata: Record<string, string>;
    };
} & T) | undefined;
//# sourceMappingURL=targets-handler.d.ts.map
import type { UpsertRemoteResponse } from './api/types.js';
export type FileToUpload = {
    name: string;
    path: string;
};
export type PushOptions = {
    domain: string;
    apiKey: string;
    organization: string;
    project: string;
    mountPath: string;
    files: FileToUpload[];
    defaultBranch: string;
    commit: {
        message: string;
        branchName: string;
        author: {
            name: string;
            email: string;
        };
        sha?: string;
        url?: string;
        createdAt?: string;
        namespace?: string;
        repository?: string;
    };
    version?: string;
    onUploadStart?: (remote: UpsertRemoteResponse) => void;
};
export type PushResult = {
    pushId: string;
};
export declare function pushFiles({ domain, apiKey, organization, project, mountPath, files, defaultBranch, commit, version, onUploadStart, }: PushOptions): Promise<PushResult>;
export declare function collectFilesToPush(files: string[]): FileToUpload[];
//# sourceMappingURL=push.d.ts.map
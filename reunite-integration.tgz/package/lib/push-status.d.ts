import type { PushResponse } from './api/types.js';
export type BuildType = 'preview' | 'production';
export type PushStatusOptions = {
    domain: string;
    apiKey: string;
    organization: string;
    project: string;
    pushId: string;
    version?: string;
};
export type WaitForDeploymentOptions = PushStatusOptions & {
    buildType: BuildType;
    maxExecutionTime?: number;
    retryIntervalMs?: number;
    startTime?: number;
    onRetry?: (push: PushResponse) => void | Promise<void>;
};
export declare function getPushStatus(options: PushStatusOptions): Promise<PushResponse>;
export declare function waitForDeployment({ buildType, maxExecutionTime, retryIntervalMs, startTime, onRetry, ...options }: WaitForDeploymentOptions): Promise<PushResponse>;
//# sourceMappingURL=push-status.d.ts.map
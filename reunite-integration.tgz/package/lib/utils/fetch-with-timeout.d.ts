export type FetchWithTimeoutOptions = RequestInit & {
    timeout?: number;
};
export default _default;
declare function _default(url: string, { timeout, ...options }?: FetchWithTimeoutOptions): Promise<Response>;
//# sourceMappingURL=fetch-with-timeout.d.ts.map
export declare function getProxyUrl(): string | undefined;
export declare function shouldBypassProxy(url: string): boolean;
//# sourceMappingURL=proxy-env.d.ts.map
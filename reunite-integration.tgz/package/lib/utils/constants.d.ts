export declare const DEFAULT_FETCH_TIMEOUT = 6000;
export declare const DEFAULT_CLI_VERSION = "2.0";
//# sourceMappingURL=constants.d.ts.map
import type { Source } from '../resolve.js';
export declare class YamlParseError extends Error {
    originalError: Error;
    source: Source;
    col: number;
    line: number;
    constructor(originalError: Error, source: Source);
}
//# sourceMappingURL=yaml-parse-error.d.ts.map
import type { Config } from '../config/index.js';
import type { Document } from '../resolve.js';
import type { NormalizedProblem } from '../walk.js';
export declare function lintGraphqlDocument(opts: {
    document: Document;
    config: Config;
}): NormalizedProblem[];
//# sourceMappingURL=lint-graphql.d.ts.map
export declare const GRAPHQL_EXTENSIONS: string[];
export declare function isGraphqlRef(ref: string): boolean;
//# sourceMappingURL=detect-graphql.d.ts.map
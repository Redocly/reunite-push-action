import { type ASTNode, type ASTVisitor } from 'graphql';
import type { Config } from '../config/index.js';
import type { Source } from '../resolve.js';
import type { NormalizedProblem, ProblemSeverity, Loc } from '../walk.js';
import type { GraphqlNodeKind } from './node-kinds.js';
export type GraphqlProblem = {
    message: string;
    node?: ASTNode;
    loc?: {
        start: Loc;
        end?: Loc;
    };
    suggest?: string[];
    ruleId?: string;
    severity?: ProblemSeverity;
};
export type GraphqlUserContext = {
    report(problem: GraphqlProblem): void;
    source: Source;
    config?: Config;
    ancestors: ASTNode[];
};
export type GraphqlVisitFunction = (node: any, ctx: GraphqlUserContext) => void;
export type GraphqlVisitorNode = GraphqlVisitFunction | {
    enter?: GraphqlVisitFunction;
    leave?: GraphqlVisitFunction;
};
export type GraphqlVisitor = Partial<Record<GraphqlNodeKind, GraphqlVisitorNode>>;
export type GraphqlRule = (options: Record<string, any>) => GraphqlVisitor | GraphqlVisitor[];
type ContextOptions = {
    ruleId: string;
    severity: ProblemSeverity;
    message?: string;
    source: Source;
    config?: Config;
    problems: NormalizedProblem[];
};
export declare function toAstVisitor(visitor: GraphqlVisitor, opts: ContextOptions): ASTVisitor;
export declare function nodeToLoc(node?: ASTNode): {
    start: {
        line: number;
        col: number;
    };
    end: {
        line: number;
        col: number;
    };
} | undefined;
export {};
//# sourceMappingURL=visitor.d.ts.map
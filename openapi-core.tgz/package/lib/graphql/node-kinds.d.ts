import type { Kind } from 'graphql';
export type GraphqlNodeKind = `${Kind}`;
export declare const graphqlNodeKinds: GraphqlNodeKind[];
//# sourceMappingURL=node-kinds.d.ts.map
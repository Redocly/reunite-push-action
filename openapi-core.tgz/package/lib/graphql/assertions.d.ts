import type { GraphqlRule } from './visitor.js';
export declare const GraphqlAssertions: GraphqlRule;
//# sourceMappingURL=assertions.d.ts.map
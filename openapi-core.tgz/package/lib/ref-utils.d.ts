import type { Source } from './resolve.js';
import type { Oas3Example, OasRef } from './typings/openapi.js';
import type { ResolveResult, UserContext } from './walk.js';
export declare function joinPointer(base: string, key: string | number): string;
export declare function isRef(node: unknown): node is OasRef;
export declare function isRefWithSiblings(node: unknown): node is OasRef & Record<string, unknown>;
export declare function isExternalValue(node: unknown): node is Oas3Example & {
    externalValue: string;
};
export declare class Location {
    source: Source;
    pointer: string;
    constructor(source: Source, pointer: string);
    child(components: (string | number)[] | string | number): Location;
    key(): any;
    get absolutePointer(): string;
}
export declare function unescapePointerFragment(fragment: string): string;
export declare function escapePointerFragment<T extends string | number>(fragment: T): T;
export declare function parseRef(ref: string): {
    uri: string | null;
    pointer: string[];
};
export declare function parsePointer(pointer: string): string[];
export declare function pointerBaseName(pointer: string): string;
export declare function refBaseName(ref: string): string;
export declare function isAbsoluteUrl(ref: string): boolean;
export declare function getDir(filePath: string): string;
export declare function resolvePath(base: string, relative: string): string;
export declare function isMappingRef(mapping: string): boolean;
export declare function isAnchor(ref: string): boolean;
export declare function replaceRef(ref: OasRef, resolved: ResolveResult<any>, ctx: UserContext): void;
//# sourceMappingURL=ref-utils.d.ts.map
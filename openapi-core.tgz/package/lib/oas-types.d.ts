import type { GraphqlRule } from './graphql/visitor.js';
import type { NodeType } from './types/index.js';
import type { BuiltInAsync2RuleId, BuiltInAsync3RuleId, BuiltInArazzo1RuleId, BuiltInOAS2RuleId, BuiltInOAS3RuleId, BuiltInOverlay1RuleId, BuiltInCommonRuleId, BuiltInOpenRpc1RuleId, BuiltInGraphqlRuleId, BuiltInOas2DecoratorId, BuiltInOas3DecoratorId } from './types/redocly-yaml.js';
import type { Oas3Rule, Oas3Decorator, Oas2Rule, Oas2Decorator, Async2Decorator, Async2Rule, Async3Decorator, Async3Rule, Arazzo1Decorator, Arazzo1Rule, Overlay1Decorator, Overlay1Rule, OpenRpc1Decorator, OpenRpc1Rule } from './visitors.js';
export declare const specVersions: readonly ['oas2', 'oas3_0', 'oas3_1', 'oas3_2', 'async2', 'async3', 'arazzo1', 'arazzo1_1', 'overlay1', 'openrpc1', 'graphql'];
export type SpecVersion = (typeof specVersions)[number];
/** Characters allowed in a Components Object key by the OpenAPI and AsyncAPI specs. */
export declare const COMPONENT_NAME_CHARS = "a-zA-Z0-9\\.\\-_";
export type SpecMajorVersion = 'oas2' | 'oas3' | 'async2' | 'async3' | 'arazzo1' | 'arazzo1_1' | 'overlay1' | 'openrpc1' | 'graphql';
export type RuleMap<Key extends string, RuleConfig, T> = Record<T extends 'built-in' ? Key : string, RuleConfig>;
export type Oas3RuleSet<T = undefined> = RuleMap<BuiltInOAS3RuleId | BuiltInCommonRuleId | 'assertions', Oas3Rule, T>;
export type Oas2RuleSet<T = undefined> = RuleMap<BuiltInOAS2RuleId | BuiltInCommonRuleId | 'assertions', Oas2Rule, T>;
export type Async2RuleSet<T = undefined> = RuleMap<BuiltInAsync2RuleId | BuiltInCommonRuleId | 'assertions', Async2Rule, T>;
export type Async3RuleSet<T = undefined> = RuleMap<BuiltInAsync3RuleId | BuiltInCommonRuleId | 'assertions', Async3Rule, T>;
export type Arazzo1RuleSet<T = undefined> = RuleMap<BuiltInArazzo1RuleId | BuiltInCommonRuleId | 'assertions', Arazzo1Rule, T>;
export type Overlay1RuleSet<T = undefined> = RuleMap<BuiltInOverlay1RuleId | BuiltInCommonRuleId | 'assertions', Overlay1Rule, T>;
export type OpenRpc1RuleSet<T = undefined> = RuleMap<BuiltInOpenRpc1RuleId | BuiltInCommonRuleId | 'assertions', OpenRpc1Rule, T>;
export type GraphqlRuleSet<T = undefined> = RuleMap<BuiltInGraphqlRuleId | 'struct' | 'assertions', GraphqlRule, T>;
export type Oas3DecoratorsSet<T = undefined> = Record<T extends 'built-in' ? BuiltInOas3DecoratorId : string, Oas3Decorator>;
export type Oas2DecoratorsSet<T = undefined> = Record<T extends 'built-in' ? BuiltInOas2DecoratorId : string, Oas2Decorator>;
export type Async2DecoratorsSet = Record<string, Async2Decorator>;
export type Async3DecoratorsSet = Record<string, Async3Decorator>;
export type Arazzo1DecoratorsSet = Record<string, Arazzo1Decorator>;
export type Overlay1DecoratorsSet = Record<string, Overlay1Decorator>;
export type OpenRpc1DecoratorsSet = Record<string, OpenRpc1Decorator>;
export declare function getTypes(spec: SpecVersion): Record<string, NodeType>;
//# sourceMappingURL=oas-types.d.ts.map
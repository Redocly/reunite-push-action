import { type EntityFileSchema, type EntityBaseFileSchema, type ScorecardConfig } from '@redocly/config';
import type { JSONSchema } from 'json-schema-to-ts';
import { type Config } from './config/index.js';
import { BaseResolver, type Document } from './resolve.js';
import { type Assertion } from './rules/common/assertions/index.js';
import { type NormalizedProblem, type ProblemSeverity } from './walk.js';
export declare function lintEntityFile(opts: {
    document: Document;
    entitySchema: JSONSchema;
    entityDefaultSchema: JSONSchema;
    severity?: ProblemSeverity;
    externalRefResolver?: BaseResolver;
    assertionConfig?: Record<string, Assertion>;
}): Promise<NormalizedProblem[]>;
export declare function lintEntityWithScorecardLevel(entity: EntityFileSchema | EntityBaseFileSchema, scorecardLevel: NonNullable<ScorecardConfig['levels']>[number], document?: Document): Promise<NormalizedProblem[]>;
export declare function lintSchema(opts: {
    schema: unknown;
    schemaKey: string;
    config: Config;
    specType: string;
    sourceDocument: Document;
    externalRefResolver?: BaseResolver;
}): Promise<NormalizedProblem[]>;
//# sourceMappingURL=lint-entity.d.ts.map
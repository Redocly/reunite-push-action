import type { Arazzo1RuleSet, Async2RuleSet, Async3RuleSet, Oas2RuleSet, Oas3RuleSet, Overlay1RuleSet, OpenRpc1RuleSet, GraphqlRuleSet, SpecVersion } from '../oas-types.js';
import type { ProblemSeverity } from '../walk.js';
import type { Config } from './config.js';
export type InitializedRule = {
    severity: ProblemSeverity;
    ruleId: string;
    visitor: any;
};
export declare function initRules(rules: (Oas3RuleSet | Oas2RuleSet | Async2RuleSet | Async3RuleSet | Arazzo1RuleSet | Overlay1RuleSet | OpenRpc1RuleSet | GraphqlRuleSet)[], config: Config, type: 'rules' | 'preprocessors' | 'decorators', specVersion: SpecVersion): InitializedRule[];
//# sourceMappingURL=rules.d.ts.map
import { type Oas2RuleSet, type Oas3RuleSet, type Async2RuleSet, type Async3RuleSet, type Arazzo1RuleSet, type Overlay1RuleSet, type OpenRpc1RuleSet, type GraphqlRuleSet, type SpecVersion, type SpecMajorVersion } from '../oas-types.js';
import type { Document, ResolvedRefMap } from '../resolve.js';
import type { NodeType } from '../types/index.js';
import type { NormalizedProblem } from '../walk.js';
import type { DecoratorConfig, Plugin, PreprocessorConfig, ResolveConfig, ResolvedConfig, RuleConfig, RuleSettings, IgnoreConfig } from './types.js';
export declare class Config {
    resolvedConfig: ResolvedConfig;
    configPath?: string;
    document?: Document;
    resolvedRefMap?: ResolvedRefMap;
    resolve: ResolveConfig;
    _alias?: string;
    plugins: Plugin[];
    ignore: IgnoreConfig;
    doNotResolveExamples: boolean;
    rules: Record<SpecVersion, Record<string, RuleConfig>>;
    preprocessors: Record<SpecVersion, Record<string, PreprocessorConfig>>;
    decorators: Record<SpecVersion, Record<string, DecoratorConfig>>;
    private _usedRules;
    private _usedVersions;
    constructor(resolvedConfig: ResolvedConfig, opts?: {
        configPath?: string;
        document?: Document;
        resolvedRefMap?: ResolvedRefMap;
        alias?: string;
        plugins?: Plugin[];
        ignore?: IgnoreConfig;
    });
    forAlias(alias?: string): Config;
    clearIgnoreForRef(ref: string): void;
    saveIgnore(): void;
    addIgnore(problem: NormalizedProblem): void;
    addProblemToIgnore(problem: NormalizedProblem): NormalizedProblem;
    extendTypes(types: Record<string, NodeType>, version: SpecVersion): Record<string, NodeType>;
    getRuleSettings(ruleId: string, oasVersion: SpecVersion): RuleSettings;
    getPreprocessorSettings(ruleId: string, oasVersion: SpecVersion): RuleSettings;
    getDecoratorSettings(ruleId: string, oasVersion: SpecVersion): RuleSettings;
    getUnusedRules(): {
        rules: string[];
        preprocessors: string[];
        decorators: string[];
    };
    getRulesForSpecVersion(version: SpecMajorVersion): Arazzo1RuleSet[] | Async2RuleSet[] | Async3RuleSet[] | GraphqlRuleSet[] | Oas2RuleSet[] | Oas3RuleSet[] | OpenRpc1RuleSet[] | Overlay1RuleSet[];
    skipRules(rules?: string[]): void;
    skipPreprocessors(preprocessors?: string[]): void;
    skipDecorators(decorators?: string[]): void;
}
//# sourceMappingURL=config.d.ts.map
import { BaseResolver, type Document, type ResolvedRefMap } from '../resolve.js';
import type { Plugin, ResolvedConfig, RawGovernanceConfig } from './types.js';
export type PluginResolveInfo = {
    absolutePath: string;
    rawPath: string;
    isModule: boolean;
};
export type ConfigOptions = {
    rawConfigDocument?: Document;
    configPath?: string;
    externalRefResolver?: BaseResolver;
    customExtends?: string[];
    skipPluginEval?: boolean;
};
export declare function resolveConfig({ rawConfigDocument, configPath, externalRefResolver, customExtends, skipPluginEval, }: ConfigOptions): Promise<{
    resolvedConfig: ResolvedConfig;
    resolvedRefMap: ResolvedRefMap;
    plugins: Plugin[];
}>;
export declare const preResolvePluginPath: (plugin: string | Plugin, base: string, rootConfigDir: string) => Plugin | PluginResolveInfo;
export declare function resolvePlugins(plugins: (string | Plugin)[], configDir: string, skipPluginEval?: boolean): Promise<Plugin[]>;
export declare function resolvePreset(presetName: string, plugins: Plugin[]): RawGovernanceConfig;
//# sourceMappingURL=config-resolvers.d.ts.map
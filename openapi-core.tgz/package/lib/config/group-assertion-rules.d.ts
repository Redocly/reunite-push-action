import type { RawGovernanceConfig, RuleConfig, Plugin } from './types.js';
export declare function groupAssertionRules(config: RawGovernanceConfig, plugins: Plugin[]): Record<string, RuleConfig>;
//# sourceMappingURL=group-assertion-rules.d.ts.map
import { type UserContext } from '../walk.js';
import { type Plugin, type RawGovernanceConfig } from './types.js';
export declare function bundleExtends({ node, ctx, plugins, }: {
    node: RawGovernanceConfig;
    ctx: UserContext;
    plugins: Plugin[];
}): RawGovernanceConfig;
//# sourceMappingURL=bundle-extends.d.ts.map
import type { OasRef } from '../typings/openapi.js';
import type { ResolveResult, UserContext } from '../walk.js';
import { type PluginResolveInfo } from './config-resolvers.js';
import type { Plugin } from './types.js';
export type PluginsCollectorVisitorData = {
    plugins: (PluginResolveInfo | Plugin)[];
    rootConfigDir: string;
};
export declare const pluginsCollectorVisitor: import("../visitors.js").NormalizedOasVisitors<{
    ref: {};
    ConfigGovernance: {
        leave(node: unknown, ctx: UserContext): void;
    };
    ConfigApisProperties: {
        leave(node: unknown, ctx: UserContext): void;
    };
    ScorecardClassicLevel: {
        leave(node: unknown, ctx: UserContext): void;
    };
    ConfigRoot: {
        leave(node: unknown, ctx: UserContext): void;
    };
}>;
export type ConfigBundlerVisitorData = {
    plugins: Plugin[];
    skipPluginEval?: boolean;
};
export declare const configBundlerVisitor: import("../visitors.js").NormalizedOasVisitors<{
    ref: {
        leave(node: OasRef, ctx: UserContext, resolved: ResolveResult<any>): void;
    };
    ConfigGovernance: {
        leave(node: unknown, ctx: UserContext): void;
    };
    ConfigApisProperties: {
        leave(node: unknown, ctx: UserContext): void;
    };
    ScorecardClassicLevel: {
        leave(node: unknown, ctx: UserContext): void;
    };
    ConfigRoot: {
        leave(node: unknown, ctx: UserContext): void;
    };
}>;
//# sourceMappingURL=visitors.d.ts.map
import { BaseResolver, type ResolvedRefMap } from '../resolve.js';
import { Config } from './config.js';
import type { RawUniversalConfig, IgnoreConfig } from './types.js';
export declare function loadIgnoreConfig(configPath: string | undefined, resolver: BaseResolver): Promise<IgnoreConfig>;
export declare function loadConfig(options?: {
    configPath?: string;
    customExtends?: string[];
    externalRefResolver?: BaseResolver;
    skipPluginEval?: boolean;
}): Promise<Config>;
export declare function findConfig(dir?: string): string | undefined;
type CreateConfigOptions = {
    configPath?: string;
    externalRefResolver?: BaseResolver;
    resolvedRefMap?: ResolvedRefMap;
    ignore?: IgnoreConfig;
};
export declare function createConfig(config?: string | RawUniversalConfig, { configPath, externalRefResolver, ignore }?: CreateConfigOptions): Promise<Config>;
export {};
//# sourceMappingURL=load.d.ts.map
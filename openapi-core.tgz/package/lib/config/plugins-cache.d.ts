import type { Plugin } from './types.js';
export declare function hasCachedPlugin(absolutePluginPath: string): boolean;
export declare function getCachedPlugins(absolutePluginPath: string): Plugin[] | undefined;
export declare function setCachedPlugins(absolutePluginPath: string, plugins: Plugin[]): void;
export declare function getPluginCacheVersion(): number;
export declare const clearPluginsCache: () => void;
export declare function loadPluginModule(absolutePluginPath: string): Promise<Record<string, unknown>>;
//# sourceMappingURL=plugins-cache.d.ts.map
import type { OpenRpc1Rule } from '../../visitors.js';
export declare const NoUnusedComponents: OpenRpc1Rule;
//# sourceMappingURL=no-unused-components.d.ts.map
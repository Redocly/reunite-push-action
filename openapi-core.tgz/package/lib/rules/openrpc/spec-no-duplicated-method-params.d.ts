import type { OpenRpc1Rule } from '../../visitors.js';
export declare const NoDuplicatedMethodParams: OpenRpc1Rule;
//# sourceMappingURL=spec-no-duplicated-method-params.d.ts.map
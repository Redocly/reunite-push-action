import type { OpenRpc1Rule } from '../../visitors.js';
export declare const NoRequiredParamsAfterOptional: OpenRpc1Rule;
//# sourceMappingURL=spec-no-required-params-after-optional.d.ts.map
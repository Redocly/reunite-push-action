import type { OpenRpc1RuleSet } from '../../oas-types.js';
export declare const rules: OpenRpc1RuleSet<'built-in'>;
export declare const preprocessors: {};
//# sourceMappingURL=index.d.ts.map
import type { Context as AjvContext } from '@redocly/ajv/dist/2020.js';
import { Location } from '../ref-utils.js';
import type { ResolvedRefChainHop } from '../resolve.js';
import type { Async2Operation } from '../typings/asyncapi2.js';
import type { Async3Operation } from '../typings/asyncapi3.js';
import type { Oas3Schema, Oas3Tag, Oas3_2Tag, Oas3_1Schema, OasRef, Referenced } from '../typings/openapi.js';
import type { Oas2Schema, Oas2Tag } from '../typings/swagger.js';
import type { NonUndefined, UserContext } from '../walk.js';
import { type AjvValidator } from './ajv.js';
export type AnySchema = Oas3Schema | Oas3_1Schema | (Oas2Schema & {
    anyOf?: undefined;
    oneOf?: undefined;
});
export declare const resolveSchema: <T extends NonUndefined>(schemaOrRef: Referenced<T> | undefined, ctx: UserContext, location?: Location) => {
    schema?: T;
    location?: Location;
    chain?: ResolvedRefChainHop[];
};
export declare const schemaHasProperty: (schemaOrRef: Referenced<AnySchema> | undefined, propertyName: string, ctx: UserContext, visited?: Set<AnySchema | OasRef>, resolveLocation?: Location) => boolean;
export declare function oasTypeOf(value: unknown): "array" | "bigint" | "boolean" | "function" | "integer" | "null" | "number" | "object" | "string" | "symbol" | "undefined";
type SecuredOperation = Async2Operation | Async3Operation;
export declare function hasSecurityRequirements(node: {
    security?: unknown;
} | undefined): boolean;
export declare function isAsyncOperationSecured(operation: SecuredOperation | undefined, resolve: UserContext['resolve'], resolveFrom?: string): boolean;
/**
 * Checks if value matches specified JSON schema type
 *
 * @param {*} value - value to check
 * @param {JSONSchemaType} type - JSON Schema type
 * @returns boolean
 */
export declare function matchesJsonSchemaType(value: unknown, type: string, nullable: boolean): boolean;
export declare function missingRequiredField(type: string, field: string): string;
export declare function missingRequiredOneOfFields(type: string, fields: string[]): string;
export declare function fieldNonEmpty(type: string, field: string): string;
export declare function validateDefinedAndNonEmpty({ fieldName, value, ctx, reference, }: {
    fieldName: string;
    value: any;
    ctx: UserContext;
    reference?: string;
}): void;
export declare function validateOneOfDefinedAndNonEmpty({ fieldNames, value, ctx, reference, }: {
    fieldNames: string[];
    value: any;
    ctx: UserContext;
    reference?: string;
}): void;
export declare function getSuggest(given: string, variants: string[]): string[];
export declare function getExampleValueToValidate(example: unknown): {
    value: unknown;
    field: 'dataValue' | 'value';
} | undefined;
export declare function validateExample({ example, schema, options, reference, }: {
    example: any;
    schema: Referenced<Oas3Schema | Oas3_1Schema>;
    options: {
        location: Location;
        ctx: UserContext;
        validator: AjvValidator;
        allowAdditionalProperties: boolean;
        ajvContext?: AjvContext;
    };
    reference?: string;
}): void;
export declare function validateSchemaEnumType(schemaEnum: string[], propertyValue: string, propName: string, refLocation: Location | undefined, { report, location }: UserContext, documentationLink?: string): void;
export declare function validateResponseCodes({ responseCodes, codeRange, report, reference, disallowDefault, }: {
    responseCodes: string[];
    codeRange: string;
    report: UserContext['report'];
    reference?: string;
    disallowDefault?: boolean;
}): void;
export declare function getTagName(tag: Oas2Tag | Oas3Tag | Oas3_2Tag, ignoreCase: boolean): string;
export {};
//# sourceMappingURL=utils.d.ts.map
import type { AsyncAPIStatsAccumulator, OASStatsAccumulator } from '../../typings/common.js';
import type { Oas3Link, Oas3Operation, Oas3Parameter, Oas3Tag, Oas3_2Tag, OasRef } from '../../typings/openapi.js';
import type { Oas2Parameter } from '../../typings/swagger.js';
import type { UserContext } from '../../walk.js';
export declare const StatsOAS: (statsAccumulator: OASStatsAccumulator) => {
    SpecExtension: {
        enter(_node: unknown, ctx: UserContext): void;
    };
    XCodeSampleList: {
        enter(_node: unknown, ctx: UserContext): void;
    };
    ExamplesMap: {
        enter(_node: unknown, ctx: UserContext): void;
    };
    EnumDescriptions: {
        enter(_node: unknown, ctx: UserContext): void;
    };
    TagGroups: {
        enter(_node: unknown, ctx: UserContext): void;
    };
    Logo: {
        enter(_node: unknown, ctx: UserContext): void;
    };
    XServerList: {
        enter(_node: unknown, ctx: UserContext): void;
    };
    XUsePkce: {
        enter(_node: unknown, ctx: UserContext): void;
    };
    Operation: {
        enter(_node: unknown, ctx: UserContext): void;
    };
    ExternalDocs: {
        leave(): void;
    };
    ref: {
        enter(ref: OasRef): void;
    };
    Tag: {
        leave(tag: Oas3Tag | Oas3_2Tag): void;
    };
    Link: {
        leave(link: Oas3Link): void;
    };
    WebhooksMap: {
        enter(_node: unknown, ctx: UserContext): void;
        Operation: {
            leave(operation: Oas3Operation): void;
        };
    };
    Paths: {
        PathItem: {
            leave(): void;
            Operation: {
                leave(operation: Oas3Operation): void;
            };
            Parameter: {
                leave(parameter: Oas2Parameter | Oas3Parameter): void;
            };
        };
    };
    NamedSchemas: {
        Schema: {
            leave(): void;
        };
    };
    Root: {
        leave(): void;
    };
};
export declare const StatsAsync2: (statsAccumulator: AsyncAPIStatsAccumulator) => {
    SpecExtension: {
        enter(_node: unknown, ctx: UserContext): void;
    };
    ExternalDocs: {
        leave(): void;
    };
    ref: {
        enter(ref: OasRef): void;
    };
    Tag: {
        leave(tag: Oas3Tag): void;
    };
    ChannelMap: {
        Channel: {
            leave(): void;
            Operation: {
                leave(operation: any): void;
            };
            Parameter: {
                leave(_: unknown, { key }: UserContext): void;
            };
        };
    };
    NamedSchemas: {
        Schema: {
            leave(): void;
        };
    };
    Root: {
        leave(): void;
    };
};
export declare const StatsAsync3: (statsAccumulator: AsyncAPIStatsAccumulator) => {
    SpecExtension: {
        enter(_node: unknown, ctx: UserContext): void;
    };
    ExternalDocs: {
        leave(): void;
    };
    ref: {
        enter(ref: OasRef): void;
    };
    Tag: {
        leave(tag: Oas3Tag): void;
    };
    NamedChannels: {
        Channel: {
            leave(): void;
            Parameter: {
                leave(_: unknown, { key }: UserContext): void;
            };
        };
    };
    NamedOperations: {
        Operation: {
            leave(operation: any): void;
        };
    };
    NamedSchemas: {
        Schema: {
            leave(): void;
        };
    };
    Root: {
        leave(): void;
    };
};
//# sourceMappingURL=stats.d.ts.map
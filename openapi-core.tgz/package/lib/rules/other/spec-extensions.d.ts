import type { StatsRow, SpecVendorExtensionsAccumulator } from '../../typings/common.js';
import type { UserContext } from '../../walk.js';
export declare const StatsSpecExtensions: (accumulator: SpecVendorExtensionsAccumulator) => {
    any: {
        enter(node: unknown, ctx: UserContext): void;
    };
};
export declare function applySpecExtensionsStats(accumulator: SpecVendorExtensionsAccumulator, statsRow: StatsRow): void;
//# sourceMappingURL=spec-extensions.d.ts.map
import type { Async3Rule } from '../../visitors.js';
export declare const SpecRefTargets: Async3Rule;
//# sourceMappingURL=spec-ref-targets.d.ts.map
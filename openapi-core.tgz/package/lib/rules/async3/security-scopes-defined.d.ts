import type { Async3Rule } from '../../visitors.js';
export declare const SecurityScopesDefined: Async3Rule;
//# sourceMappingURL=security-scopes-defined.d.ts.map
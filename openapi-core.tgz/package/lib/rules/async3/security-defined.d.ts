import type { Async3Rule } from '../../visitors.js';
export declare const SecurityDefined: Async3Rule;
//# sourceMappingURL=security-defined.d.ts.map
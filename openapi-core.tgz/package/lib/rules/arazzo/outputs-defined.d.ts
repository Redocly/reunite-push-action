import type { Arazzo1Rule } from '../../visitors.js';
export declare const OutputsDefined: Arazzo1Rule;
//# sourceMappingURL=outputs-defined.d.ts.map
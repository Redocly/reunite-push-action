import type { Arazzo1Rule } from '../../visitors.js';
export declare const SpecStepMutuallyExclusiveFields: Arazzo1Rule;
//# sourceMappingURL=spec-step-mutually-exclusive-fields.d.ts.map
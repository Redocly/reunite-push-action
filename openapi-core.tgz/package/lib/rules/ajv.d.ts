import { type ErrorObject, type Context as AjvContext } from '@redocly/ajv/dist/2020.js';
import { type Location } from '../ref-utils.js';
import type { Oas3Schema, Oas3_1Schema } from '../typings/openapi.js';
import type { ResolveFn, UserContext } from '../walk.js';
export declare class AjvValidator {
    private instances;
    validate(data: unknown, schema: Oas3Schema | Oas3_1Schema, options: {
        schemaLoc: Location;
        instancePath: string;
        resolve: ResolveFn;
        allowAdditionalProperties: boolean;
        ajvContext?: AjvContext;
        specVersion: UserContext['specVersion'];
    }): {
        valid: boolean;
        errors: (ErrorObject & {
            suggest?: string[];
        })[];
    };
    private getAjv;
    private getValidator;
}
//# sourceMappingURL=ajv.d.ts.map
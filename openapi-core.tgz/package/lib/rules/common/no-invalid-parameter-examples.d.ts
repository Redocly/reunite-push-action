import type { Oas2Rule, Oas3Rule } from '../../visitors.js';
export declare const NoInvalidParameterExamples: Oas3Rule | Oas2Rule;
//# sourceMappingURL=no-invalid-parameter-examples.d.ts.map
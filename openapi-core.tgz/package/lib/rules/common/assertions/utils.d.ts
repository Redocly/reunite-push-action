import type { AssertionContext, AssertResult } from '../../../config/index.js';
import type { Oas2Visitor, Oas3Visitor, VisitFunction } from '../../../visitors.js';
import { type Asserts } from './asserts.js';
import type { Assertion, AssertionDefinition } from './index.js';
export type AssertToApply = {
    name: keyof Asserts;
    conditions: any;
    runsOnKeys: boolean;
    runsOnValues: boolean;
};
type RunAssertionParams = {
    ctx: AssertionContext;
    assert: AssertToApply;
    assertionProperty?: string;
};
declare const assertionMessageTemplates: {
    readonly problems: '{{problems}}';
    readonly assertionName: '{{assertionName}}';
    readonly nodeType: '{{nodeType}}';
    readonly key: '{{key}}';
    readonly property: '{{property}}';
    readonly file: '{{file}}';
    readonly pointer: '{{pointer}}';
};
type PlaceholderKeys = keyof typeof assertionMessageTemplates;
export declare function getAssertsToApply(assertion: AssertionDefinition): AssertToApply[];
export declare function buildVisitorObject(assertion: Assertion, subjectVisitor: VisitFunction<any>): Oas2Visitor | Oas3Visitor;
export declare function buildSubjectVisitor(assertId: string, assertion: Assertion): VisitFunction<any>;
export declare function getProblemsMessage(problems: AssertResult[]): string;
export declare function getFilenameFromPath(absoluteRef: string): string;
export declare function interpolateMessagePlaceholders(message: string, placeholders: Record<PlaceholderKeys, string>): string;
export declare function runAssertion({ assert, ctx, assertionProperty, }: RunAssertionParams): AssertResult[];
export {};
//# sourceMappingURL=utils.d.ts.map
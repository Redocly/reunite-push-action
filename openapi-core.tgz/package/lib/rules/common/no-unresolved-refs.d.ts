import type { Location } from '../../ref-utils.js';
import type { Oas2Rule, Oas3Rule, Async2Rule, Async3Rule, Arazzo1Rule, Overlay1Rule } from '../../visitors.js';
import type { ResolveResult, Problem } from '../../walk.js';
export declare const NoUnresolvedRefs: Oas3Rule | Oas2Rule | Async2Rule | Async3Rule | Arazzo1Rule | Overlay1Rule;
export declare function reportUnresolvedRef(resolved: ResolveResult<any>, report: (m: Problem) => void, location: Location): void;
//# sourceMappingURL=no-unresolved-refs.d.ts.map
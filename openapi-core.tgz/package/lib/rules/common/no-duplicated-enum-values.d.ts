import type { Arazzo1Rule, Async2Rule, Async3Rule, Oas2Rule, Oas3Rule } from '../../visitors.js';
export declare const NoDuplicatedEnumValues: Oas3Rule | Oas2Rule | Async3Rule | Async2Rule | Arazzo1Rule;
//# sourceMappingURL=no-duplicated-enum-values.d.ts.map
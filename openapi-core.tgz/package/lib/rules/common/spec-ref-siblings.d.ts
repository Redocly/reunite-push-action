import type { Async2Rule, Async3Rule, Oas2Rule, OpenRpc1Rule } from '../../visitors.js';
export declare const SpecRefSiblings: Oas2Rule | Async2Rule | Async3Rule | OpenRpc1Rule;
//# sourceMappingURL=spec-ref-siblings.d.ts.map
import { type Oas3Rule, type Oas2Rule } from '../../visitors.js';
export declare const PathParamsDefined: Oas3Rule | Oas2Rule;
//# sourceMappingURL=path-params-defined.d.ts.map
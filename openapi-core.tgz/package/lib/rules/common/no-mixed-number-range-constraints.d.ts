import { type Arazzo1Rule, type Async2Rule, type Async3Rule, type Oas3Rule } from '../../visitors.js';
export declare const NoMixedNumberRangeConstraints: Oas3Rule | Async3Rule | Async2Rule | Arazzo1Rule;
//# sourceMappingURL=no-mixed-number-range-constraints.d.ts.map
import type { Oas3Rule, Oas2Rule, Async2Rule, Async3Rule, Arazzo1Rule, Overlay1Rule, OpenRpc1Rule, ConfigRule } from '../../visitors.js';
export declare const Struct: ConfigRule | Oas3Rule | Oas2Rule | Async2Rule | Async3Rule | Arazzo1Rule | Overlay1Rule | OpenRpc1Rule;
//# sourceMappingURL=struct.d.ts.map
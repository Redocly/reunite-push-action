import type { Oas3Rule } from '../../visitors.js';
export declare const SpecRefSiblings: Oas3Rule;
//# sourceMappingURL=spec-ref-siblings.d.ts.map
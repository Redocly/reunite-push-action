import type { Oas3Rule } from '../../visitors.js';
export declare const SpecQuerystringParameters: Oas3Rule;
//# sourceMappingURL=spec-querystring-parameters.d.ts.map
import type { Oas3Rule } from '../../visitors.js';
export declare const NoIllogicalCompositionKeywords: Oas3Rule;
//# sourceMappingURL=no-illogical-composition-keywords.d.ts.map
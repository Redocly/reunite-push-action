import type { Async2Rule } from '../../visitors.js';
export declare const SecurityDefined: Async2Rule;
//# sourceMappingURL=security-defined.d.ts.map
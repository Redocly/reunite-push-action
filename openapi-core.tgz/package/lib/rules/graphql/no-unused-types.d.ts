import type { GraphqlRule } from '../../graphql/visitor.js';
export declare const NoUnusedTypes: GraphqlRule;
//# sourceMappingURL=no-unused-types.d.ts.map
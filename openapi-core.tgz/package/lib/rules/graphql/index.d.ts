import type { GraphqlRuleSet } from '../../oas-types.js';
export declare const rules: GraphqlRuleSet<'built-in'>;
//# sourceMappingURL=index.d.ts.map
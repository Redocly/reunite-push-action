import type { GraphqlRule } from '../../graphql/visitor.js';
export declare const Struct: GraphqlRule;
//# sourceMappingURL=struct.d.ts.map
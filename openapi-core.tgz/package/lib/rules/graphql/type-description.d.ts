import type { GraphqlRule } from '../../graphql/visitor.js';
export declare const TypeDescription: GraphqlRule;
//# sourceMappingURL=type-description.d.ts.map
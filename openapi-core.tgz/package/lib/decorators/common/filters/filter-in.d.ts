import { type Oas2Decorator, type Oas3Decorator } from '../../../visitors.js';
export declare const FilterIn: Oas3Decorator | Oas2Decorator;
//# sourceMappingURL=filter-in.d.ts.map
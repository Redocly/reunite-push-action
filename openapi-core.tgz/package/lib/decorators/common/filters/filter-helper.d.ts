import type { UserContext } from '../../../walk.js';
export declare function filter(node: unknown, ctx: UserContext, criteria: (item: unknown) => boolean): void;
export declare function checkIfMatchByStrategy(nodeValue: any, decoratorValue: any, strategy: 'all' | 'any'): boolean;
//# sourceMappingURL=filter-helper.d.ts.map
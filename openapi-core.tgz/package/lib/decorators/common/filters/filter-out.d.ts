import { type Oas2Decorator, type Oas3Decorator } from '../../../visitors.js';
export declare const FilterOut: Oas3Decorator | Oas2Decorator;
//# sourceMappingURL=filter-out.d.ts.map
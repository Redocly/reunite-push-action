import { type Oas3DecoratorsSet } from '../../oas-types.js';
export declare const decorators: Oas3DecoratorsSet<'built-in'>;
//# sourceMappingURL=index.d.ts.map
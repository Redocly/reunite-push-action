import { type Oas2DecoratorsSet } from '../../oas-types.js';
export declare const decorators: Oas2DecoratorsSet<'built-in'>;
//# sourceMappingURL=index.d.ts.map
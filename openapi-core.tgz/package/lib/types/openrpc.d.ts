import { type NodeType } from './index.js';
export declare const OpenRpcTypes: {
    readonly Root: NodeType;
    readonly Info: NodeType;
    readonly Contact: NodeType;
    readonly License: NodeType;
    readonly Server: NodeType;
    readonly ServerList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly ServerVariable: NodeType;
    readonly ServerVariablesMap: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly Method: NodeType;
    readonly MethodList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly ContentDescriptor: NodeType;
    readonly ContentDescriptorList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly ExamplePairing: NodeType;
    readonly ExamplePairingList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly Example: NodeType;
    readonly ExampleList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly Link: NodeType;
    readonly LinkList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly ErrorObject: NodeType;
    readonly ErrorList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly Components: NodeType;
    readonly Tag: NodeType;
    readonly TagList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly ExternalDocs: NodeType;
    readonly Schema: NodeType;
    readonly SchemaProperties: NodeType;
    readonly Dependencies: NodeType;
    readonly DiscriminatorMapping: NodeType;
    readonly Discriminator: NodeType;
    readonly NamedContentDescriptors: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedSchemas: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedExamples: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedLinks: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedErrors: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedExamplePairingObjects: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedTags: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
};
//# sourceMappingURL=openrpc.d.ts.map
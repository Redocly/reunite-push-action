import { type NodeType } from './index.js';
export declare const Oas2Types: {
    readonly Root: NodeType;
    readonly Tag: NodeType;
    readonly TagList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly TagGroups: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly TagGroup: NodeType;
    readonly ExternalDocs: NodeType;
    readonly Example: NodeType;
    readonly ExamplesMap: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly EnumDescriptions: NodeType;
    readonly SecurityRequirement: NodeType;
    readonly SecurityRequirementList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly Info: NodeType;
    readonly Contact: NodeType;
    readonly License: NodeType;
    readonly Logo: NodeType;
    readonly Paths: NodeType;
    readonly PathItem: NodeType;
    readonly Parameter: NodeType;
    readonly ParameterItems: NodeType;
    readonly ParameterList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly Operation: NodeType;
    readonly Examples: NodeType;
    readonly Header: NodeType;
    readonly Responses: NodeType;
    readonly Response: NodeType;
    readonly Schema: NodeType;
    readonly Xml: NodeType;
    readonly SchemaProperties: NodeType;
    readonly NamedSchemas: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedResponses: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedParameters: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedSecuritySchemes: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly SecurityScheme: NodeType;
    readonly Scopes: NodeType;
    readonly XCodeSample: NodeType;
    readonly XCodeSampleList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly XServerList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly XServer: NodeType;
};
//# sourceMappingURL=oas2.d.ts.map
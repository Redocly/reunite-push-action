import type { NodeType } from './index.js';
export declare const Arazzo1_1Types: Record<string, NodeType>;
//# sourceMappingURL=arazzo1_1.d.ts.map
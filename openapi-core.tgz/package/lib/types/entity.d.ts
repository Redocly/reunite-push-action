import type { JSONSchema } from 'json-schema-to-ts';
import type { NodeType, ResolveTypeFn } from './index.js';
export declare const ENTITY_DISCRIMINATOR_PROPERTY_NAME = "type";
export declare const ENTITY_TYPES_WITH_API_SUPPORT: string[];
export declare function createEntityTypes(entitySchema: JSONSchema, entityDefaultSchema: JSONSchema): {
    entityTypes: Record<string, NodeType>;
    discriminatorResolver?: ResolveTypeFn;
};
//# sourceMappingURL=entity.d.ts.map
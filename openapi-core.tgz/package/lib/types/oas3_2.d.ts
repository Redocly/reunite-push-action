import { type NodeType } from './index.js';
export declare const Oas3_2Types: {
    readonly TagList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly TagGroups: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly TagGroup: NodeType;
    readonly ExternalDocs: NodeType;
    readonly ServerList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly ServerVariable: NodeType;
    readonly ServerVariablesMap: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly SecurityRequirement: NodeType;
    readonly SecurityRequirementList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly Contact: NodeType;
    readonly Paths: NodeType;
    readonly ParameterList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly Callback: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly CallbacksMap: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly RequestBody: NodeType;
    readonly MediaTypesMap: NodeType;
    readonly ExamplesMap: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly Encoding: NodeType;
    readonly EncodingMap: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly EnumDescriptions: NodeType;
    readonly Header: NodeType;
    readonly HeadersMap: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly Responses: NodeType;
    readonly Link: NodeType;
    readonly Logo: NodeType;
    readonly AllOf: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly AnyOf: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly OneOf: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly DiscriminatorMapping: NodeType;
    readonly LinksMap: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedSchemas: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedResponses: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedParameters: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedExamples: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedRequestBodies: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedHeaders: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedSecuritySchemes: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedLinks: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedCallbacks: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly ImplicitFlow: NodeType;
    readonly PasswordFlow: NodeType;
    readonly ClientCredentials: NodeType;
    readonly AuthorizationCode: NodeType;
    readonly XCodeSample: NodeType;
    readonly XCodeSampleList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly XUsePkce: NodeType;
    readonly WebhooksMap: NodeType;
    readonly Info: NodeType;
    readonly SchemaProperties: NodeType;
    readonly PatternProperties: NodeType;
    readonly License: NodeType;
    readonly NamedPathItems: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly Operation: NodeType;
    readonly DependentRequired: NodeType;
    readonly Root: NodeType;
    readonly Tag: NodeType;
    readonly Server: NodeType;
    readonly SecurityScheme: NodeType;
    readonly OAuth2Flows: NodeType;
    readonly DeviceAuthorization: NodeType;
    readonly PathItem: NodeType;
    readonly Parameter: NodeType;
    readonly Response: Omit<NodeType, "required">;
    readonly MediaType: NodeType;
    readonly Discriminator: NodeType;
    readonly Example: NodeType;
    readonly Xml: NodeType;
    readonly Schema: NodeType;
    readonly Components: NodeType;
    readonly NamedMediaTypes: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
};
//# sourceMappingURL=oas3_2.d.ts.map
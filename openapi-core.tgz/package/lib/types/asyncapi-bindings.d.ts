import { type NodeType } from './index.js';
export declare const ServerBindings: NodeType;
export declare const ChannelBindings: NodeType;
export declare const OperationBindings: NodeType;
export declare const MessageBindings: NodeType;
export declare const AsyncApiBindings: Record<string, NodeType>;
export declare const Ros2Bindings: Record<string, NodeType>;
//# sourceMappingURL=asyncapi-bindings.d.ts.map
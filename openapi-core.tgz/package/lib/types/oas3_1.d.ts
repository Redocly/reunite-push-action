import { type NodeType } from './index.js';
export declare const Oas3_1Types: {
    readonly Tag: NodeType;
    readonly TagList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly TagGroups: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly TagGroup: NodeType;
    readonly ExternalDocs: NodeType;
    readonly Server: NodeType;
    readonly ServerList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly ServerVariable: NodeType;
    readonly ServerVariablesMap: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly SecurityRequirement: NodeType;
    readonly SecurityRequirementList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly Contact: NodeType;
    readonly Paths: NodeType;
    readonly PathItem: NodeType;
    readonly Parameter: NodeType;
    readonly ParameterList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly Callback: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly CallbacksMap: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly RequestBody: NodeType;
    readonly MediaTypesMap: NodeType;
    readonly MediaType: NodeType;
    readonly Example: NodeType;
    readonly ExamplesMap: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly Encoding: NodeType;
    readonly EncodingMap: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly EnumDescriptions: NodeType;
    readonly Header: NodeType;
    readonly HeadersMap: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly Responses: NodeType;
    readonly Response: NodeType;
    readonly Link: NodeType;
    readonly Logo: NodeType;
    readonly AllOf: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly AnyOf: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly OneOf: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly Xml: NodeType;
    readonly DiscriminatorMapping: NodeType;
    readonly Discriminator: NodeType;
    readonly LinksMap: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedSchemas: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedResponses: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedParameters: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedExamples: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedRequestBodies: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedHeaders: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedSecuritySchemes: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedLinks: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly NamedCallbacks: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly ImplicitFlow: NodeType;
    readonly PasswordFlow: NodeType;
    readonly ClientCredentials: NodeType;
    readonly AuthorizationCode: NodeType;
    readonly OAuth2Flows: NodeType;
    readonly XCodeSample: NodeType;
    readonly XCodeSampleList: {
        description?: string;
        documentationLink?: string;
        name: string;
        properties: {};
        items: string;
    };
    readonly XUsePkce: NodeType;
    readonly WebhooksMap: NodeType;
    readonly Info: NodeType;
    readonly Root: NodeType;
    readonly Schema: NodeType;
    readonly SchemaProperties: NodeType;
    readonly PatternProperties: NodeType;
    readonly License: NodeType;
    readonly Components: NodeType;
    readonly NamedPathItems: {
        description?: string;
        documentationLink?: string;
        extensionsPrefix?: string;
        name: string;
        properties: {};
        additionalProperties: () => string;
    };
    readonly SecurityScheme: NodeType;
    readonly Operation: NodeType;
    readonly DependentRequired: NodeType;
};
//# sourceMappingURL=oas3_1.d.ts.map
import { type NodeType } from './index.js';
export declare const Schema: NodeType;
export declare const SchemaProperties: NodeType;
export declare const Dependencies: NodeType;
export declare const DiscriminatorMapping: NodeType;
export declare const Discriminator: NodeType;
//# sourceMappingURL=json-schema-draft7.shared.d.ts.map
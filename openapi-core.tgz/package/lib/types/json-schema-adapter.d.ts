import type { JSONSchema } from 'json-schema-to-ts';
import type { NodeType, ResolveTypeFn } from './index.js';
type ExtendedJSONSchema = JSONSchema & {
    nodeTypeName?: string;
    documentationLink?: string;
};
export declare function getNodeTypesFromJSONSchema(schemaName: string, entrySchema: ExtendedJSONSchema): {
    ctx: Record<string, NodeType>;
    discriminatorResolver?: ResolveTypeFn;
};
export {};
//# sourceMappingURL=json-schema-adapter.d.ts.map
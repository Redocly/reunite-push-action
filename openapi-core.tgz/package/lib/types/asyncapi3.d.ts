import { type NodeType } from './index.js';
export declare const AsyncApi3Types: Record<string, NodeType>;
//# sourceMappingURL=asyncapi3.d.ts.map
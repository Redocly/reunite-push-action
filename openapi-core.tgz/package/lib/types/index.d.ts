export type ScalarSchema = {
    name?: never;
    type?: 'string' | 'boolean' | 'number' | 'integer' | 'object' | 'array';
    items?: ScalarSchema;
    enum?: string[];
    isExample?: boolean;
    resolvable?: boolean;
    directResolveAs?: string;
    minimum?: number;
    description?: string;
    documentationLink?: string;
};
export type NormalizedScalarSchema = {
    name?: never;
    type?: 'string' | 'boolean' | 'number' | 'integer' | 'object' | 'array';
    items?: NormalizedScalarSchema;
    enum?: string[];
    directResolveAs?: NormalizedNodeType;
    resolvable: boolean;
    minimum?: number;
    description?: string;
    documentationLink?: string;
};
export type NodeType = {
    properties: Record<string, PropType | ResolveTypeFn>;
    additionalProperties?: PropType | ResolveTypeFn;
    items?: PropType | ResolveTypeFn;
    required?: string[] | ((value: any, key: string | number | undefined) => string[]);
    requiredOneOf?: string[];
    allowed?: (value: any) => string[] | undefined;
    extensionsPrefix?: string;
    description?: string;
    documentationLink?: string;
};
export type PropType = string | NodeType | ScalarSchema | undefined | null;
export type ResolveTypeFn = (value: any, key: string) => string | PropType;
export type NormalizedNodeType = {
    name: string;
    properties: Record<string, NormalizedPropType | NormalizedResolveTypeFn>;
    additionalProperties?: NormalizedPropType | NormalizedResolveTypeFn;
    items?: NormalizedPropType | NormalizedResolveTypeFn;
    required?: string[] | ((value: any, key: string | number | undefined) => string[]);
    requiredOneOf?: string[];
    allowed?: (value: any) => string[] | undefined;
    extensionsPrefix?: string;
    directResolveAs?: NormalizedNodeType;
    description?: string;
    documentationLink?: string;
};
type NormalizedPropType = NormalizedNodeType | NormalizedScalarSchema | null | undefined;
type NormalizedResolveTypeFn = (value: any, key: string) => NormalizedPropType;
export declare function listOf(typeName: string, opts?: {
    name?: string;
    description?: string;
    documentationLink?: string;
}): {
    description?: string;
    documentationLink?: string;
    name: string;
    properties: {};
    items: string;
};
export declare function mapOf(typeName: string, opts?: {
    description?: string;
    documentationLink?: string;
    extensionsPrefix?: string;
}): {
    description?: string;
    documentationLink?: string;
    extensionsPrefix?: string;
    name: string;
    properties: {};
    additionalProperties: () => string;
};
export declare const SpecExtension: NormalizedNodeType;
export declare function normalizeTypes(types: Record<string, NodeType>, options?: {
    doNotResolveExamples?: boolean;
}): Record<string, NormalizedNodeType>;
export declare function isNamedType(t: NormalizedPropType): t is NormalizedNodeType;
export {};
//# sourceMappingURL=index.d.ts.map
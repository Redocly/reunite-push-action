import { Config } from '../config/config.js';
import { BaseResolver, type Document } from '../resolve.js';
import { type CoreBundleOptions } from './bundle-document.js';
export { Source, Document } from '../resolve.js';
export declare function bundleOas(opts: {
    ref?: string;
    doc?: Document;
} & CoreBundleOptions): Promise<import("./bundle-document.js").BundleResult>;
export declare function createEmptyRedoclyConfig(options?: {
    configPath?: string;
    customExtends?: string[];
    externalRefResolver?: BaseResolver;
}): Config;
//# sourceMappingURL=bundle-oas.d.ts.map
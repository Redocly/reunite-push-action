import { type RuleSeverity } from '../config/types.js';
import { type SpecMajorVersion } from '../oas-types.js';
import { type ResolvedRefMap, type Document } from '../resolve.js';
import { type Oas3Visitor, type Oas2Visitor } from '../visitors.js';
import { type ComponentNamesStrategy } from './bundle-document.js';
export declare function mapTypeToComponent(typeName: string, version: SpecMajorVersion): "callbacks" | "contentDescriptors" | "definitions" | "errors" | "examplePairingObjects" | "examples" | "headers" | "links" | "mediaTypes" | "parameters" | "requestBodies" | "responses" | "schemas" | "securitySchemes" | "tags" | null;
export declare function makeBundleVisitor({ version, dereference, rootDocument, resolvedRefMap, keepUrlRefs, componentRenamingConflicts, componentNamesStrategy, }: {
    version: SpecMajorVersion;
    dereference: boolean;
    rootDocument: Document;
    resolvedRefMap: ResolvedRefMap;
    keepUrlRefs: boolean;
    componentRenamingConflicts?: RuleSeverity;
    componentNamesStrategy?: ComponentNamesStrategy;
}): Oas2Visitor | Oas3Visitor;
//# sourceMappingURL=bundle-visitor.d.ts.map
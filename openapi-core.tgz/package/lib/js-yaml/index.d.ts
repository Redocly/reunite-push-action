import { type LoadOptions, type DumpOptions } from 'js-yaml';
export declare const parseYaml: (str: string, opts?: LoadOptions) => unknown;
export declare const stringifyYaml: (obj: unknown, opts?: DumpOptions) => string;
//# sourceMappingURL=index.d.ts.map
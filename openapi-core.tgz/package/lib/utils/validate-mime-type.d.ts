import type { UserContext } from '../walk.js';
type MimeTypeParams = {
    type: 'consumes' | 'produces';
    value: any;
    ctx: UserContext;
    allowedValues: string[];
    reference?: string;
};
export declare function validateMimeTypeOAS2({ type, value, ctx, allowedValues, reference, }: MimeTypeParams): void;
export declare function validateMimeTypeOAS3({ type, value, ctx, allowedValues, reference, }: MimeTypeParams): void;
export {};
//# sourceMappingURL=validate-mime-type.d.ts.map
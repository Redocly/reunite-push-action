export declare function componentNameFromTitle(node: unknown): {
    title: string;
    name: string;
};
//# sourceMappingURL=component-name-from-title.d.ts.map
export declare function isSupportedExtension(filename: string): boolean;
//# sourceMappingURL=is-supported-extension.d.ts.map
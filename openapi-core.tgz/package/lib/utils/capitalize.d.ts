export declare function capitalize(s: string): string;
//# sourceMappingURL=capitalize.d.ts.map
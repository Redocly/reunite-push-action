export declare class HandledError extends Error {
}
export declare class AbortFlowError extends Error {
}
//# sourceMappingURL=error.d.ts.map
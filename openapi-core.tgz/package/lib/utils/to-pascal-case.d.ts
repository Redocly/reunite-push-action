export declare function toPascalCase(value: string): string;
//# sourceMappingURL=to-pascal-case.d.ts.map
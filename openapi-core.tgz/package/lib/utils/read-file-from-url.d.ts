import type { HttpResolveConfig } from '../config/index.js';
export declare function readFileFromUrl(url: string, config: HttpResolveConfig): Promise<{
    body: any;
    mimeType: any;
}>;
//# sourceMappingURL=read-file-from-url.d.ts.map
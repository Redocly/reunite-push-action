import type { RuleConfig } from '../config/types.js';
import type { Document } from '../resolve.js';
import type { Assertion } from '../rules/common/assertions/index.js';
export type AssertionConfig = Record<string, Assertion | RuleConfig>;
type AssertionsByTarget = {
    entityRules: Record<string, Assertion>;
    apiRules: Record<string, Assertion | RuleConfig>;
};
export declare function transformScorecardRulesToAssertions(entityType: string, rules: RuleConfig): AssertionConfig;
export declare function categorizeAssertions(assertionConfig: AssertionConfig): AssertionsByTarget;
export declare function findDataSchemaInDocument(schemaKey: string, schemaJson: string, document: Document): unknown;
export {};
//# sourceMappingURL=scorecards.d.ts.map
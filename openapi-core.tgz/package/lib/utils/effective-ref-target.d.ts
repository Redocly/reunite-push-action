import { type Location } from '../ref-utils.js';
import { type ResolvedRefChainHop } from '../resolve.js';
export type RefTarget = {
    node: unknown;
    location: Location;
};
export declare function effectiveRefTarget(resolved: {
    node: unknown;
    location: Location;
    chain?: ResolvedRefChainHop[];
}): RefTarget;
//# sourceMappingURL=effective-ref-target.d.ts.map
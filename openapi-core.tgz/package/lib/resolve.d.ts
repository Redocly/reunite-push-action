import type { YAMLNode, LoadOptions } from 'yaml-ast-parser';
import type { ResolveConfig } from './config/types.js';
import { YamlParseError } from './errors/yaml-parse-error.js';
import { Location } from './ref-utils.js';
import { type NormalizedNodeType } from './types/index.js';
export type CollectedRefs = Map<string, Document>;
export declare class Source {
    #private;
    absoluteRef: string;
    body: string;
    mimeType?: string | undefined;
    constructor(absoluteRef: string, body: string, mimeType?: string | undefined);
    getAst(safeLoad: (input: string, options?: LoadOptions | undefined) => YAMLNode): YAMLNode;
    getLines(): string[];
}
export declare class ResolveError extends Error {
    originalError: Error;
    constructor(originalError: Error);
}
export type Document<T = unknown> = {
    source: Source;
    parsed: T;
};
export declare function makeDocumentFromString<T = unknown>(sourceString: string, absoluteRef: string): Document<T>;
export declare class BaseResolver {
    protected config: ResolveConfig;
    cache: Map<string, Promise<Document | ResolveError>>;
    constructor(config?: ResolveConfig);
    getFiles(): Set<string>;
    resolveExternalRef(base: string | null, ref: string): string;
    loadExternalRef(absoluteRef: string): Promise<Source>;
    parseDocument(source: Source, isRoot?: boolean): Document;
    resolveDocument<T = unknown>(base: string | null, ref: string, isRoot?: boolean): Promise<Document<T> | ResolveError | YamlParseError>;
}
export type ResolvedRefChainHop = {
    node: unknown;
    document: Document;
    location: Location;
};
export type ResolvedRef = {
    resolved: false;
    isRemote: boolean;
    nodePointer?: string;
    document?: Document;
    source?: Source;
    error?: ResolveError | YamlParseError;
    node?: any;
    chain?: undefined;
} | {
    resolved: true;
    node: any;
    document: Document;
    nodePointer: string;
    isRemote: boolean;
    error?: undefined;
    chain?: ResolvedRefChainHop[];
};
export type ResolvedRefMap = Map<string, ResolvedRef>;
export declare function resolveDocument(opts: {
    rootDocument: Document;
    externalRefResolver: BaseResolver;
    rootType: NormalizedNodeType;
}): Promise<ResolvedRefMap>;
//# sourceMappingURL=resolve.d.ts.map
import type { Config, RuleSeverity } from './config/index.js';
import { YamlParseError } from './errors/yaml-parse-error.js';
import type { SpecVersion } from './oas-types.js';
import { Location } from './ref-utils.js';
import type { ResolveError, Source, ResolvedRefMap, ResolvedRefChainHop, Document } from './resolve.js';
import { type NormalizedNodeType } from './types/index.js';
import type { Referenced } from './typings/openapi.js';
import type { NormalizedOasVisitors, BaseVisitor } from './visitors.js';
type ExtendedSpecVersion = SpecVersion | 'config' | 'entity';
export type NonUndefined = string | number | boolean | symbol | bigint | object | Record<string, any>;
export type ResolveResult<T extends NonUndefined> = {
    node: T;
    location: Location;
    error?: ResolveError | YamlParseError;
    chain?: ResolvedRefChainHop[];
} | {
    node: undefined;
    location: undefined;
    error?: ResolveError | YamlParseError;
    chain?: ResolvedRefChainHop[];
};
export type ResolveFn = <T extends NonUndefined>(node: Referenced<T>, from?: string) => ResolveResult<T>;
export type UserContext = {
    report(problem: Problem): void;
    location: Location;
    rawNode: any;
    rawLocation: Location;
    resolve: ResolveFn;
    parentLocations: Record<string, Location>;
    type: NormalizedNodeType;
    key: string | number;
    parent: any;
    specVersion: ExtendedSpecVersion;
    config?: Config;
    getVisitorData: () => Record<string, unknown>;
};
export type Loc = {
    line: number;
    col: number;
};
export type PointerLocationObject = {
    source: Source;
    reportOnKey?: boolean;
    pointer: string;
};
export type LineColLocationObject = Omit<PointerLocationObject, 'pointer'> & {
    pointer: undefined;
    start: Loc;
    end?: Loc;
};
export type LocationObject = LineColLocationObject | PointerLocationObject;
export type ProblemSeverity = 'error' | 'warn';
export type Problem = {
    message: string;
    suggest?: string[];
    location?: Partial<LocationObject> | Array<Partial<LocationObject>>;
    from?: LocationObject;
    forceSeverity?: RuleSeverity;
    ruleId?: string;
    reference?: string;
};
export type NormalizedProblem = {
    message: string;
    ruleId: string;
    severity: ProblemSeverity;
    location: LocationObject[];
    from?: LocationObject;
    suggest: string[];
    ignored?: boolean;
    reference?: string;
};
export type WalkContext = {
    problems: NormalizedProblem[];
    specVersion: ExtendedSpecVersion;
    config?: Config;
    visitorsData: Record<string, Record<string, unknown>>;
    refTypes?: Map<string, NormalizedNodeType>;
};
export declare function walkDocument<T extends BaseVisitor>(opts: {
    document: Document;
    rootType: NormalizedNodeType;
    normalizedVisitors: NormalizedOasVisitors<T>;
    resolvedRefMap: ResolvedRefMap;
    ctx: WalkContext;
}): void;
export {};
//# sourceMappingURL=walk.d.ts.map
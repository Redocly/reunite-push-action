import type { NormalizedProblem } from '../walk.js';
export type Totals = {
    errors: number;
    warnings: number;
    ignored: number;
};
export type OutputFormat = 'codeframe' | 'stylish' | 'json' | 'checkstyle' | 'codeclimate' | 'summary' | 'github-actions' | 'markdown' | 'junit';
export declare function getTotals(problems: (NormalizedProblem & {
    ignored?: boolean;
})[]): Totals;
export declare function formatProblems(problems: (NormalizedProblem & {
    ignored?: boolean;
})[], opts: {
    maxProblems?: number;
    cwd?: string;
    format?: OutputFormat;
    color?: boolean;
    totals: Totals;
    version?: string;
    command?: 'bundle' | 'lint' | 'join' | 'check-config';
}): void;
export declare function xmlEscape(s: string): string;
//# sourceMappingURL=format.d.ts.map
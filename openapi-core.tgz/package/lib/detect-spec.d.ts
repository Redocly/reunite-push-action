import type { SpecMajorVersion, SpecVersion } from './oas-types.js';
export declare function getMajorSpecVersion(version: SpecVersion): SpecMajorVersion;
export declare function detectSpec(root: unknown): SpecVersion;
//# sourceMappingURL=detect-spec.d.ts.map